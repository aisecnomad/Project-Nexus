# Changelog

All notable changes to ShadowScan will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

### Changed

### Fixed

### Security

## [0.1.1] - 2026-09-24

### Added
- Frozen public corpus: 42 pinned files from 15 repositories, 30 negatives and 12 positives, with blinded AI labeling and CI annotation checks.
- Independent corpus and tenant canary tests.
- Configurable connector completion deadlines (120s default).
- SHA-256 incremental scanning for local repository roots and static cloud exports.
- Signature CI validation pipeline.
- Code-to-gateway runtime correlation with timestamped framework fingerprints.
- Guarded cache and export publication.
- Explicit credential-mixing approval and instance-credential opt-in.

### Changed
- Separate executable agent evidence from comments, strings, dependencies, documentation, and MCP server configuration.
- Count only structurally valid enabled MCP servers.
- Retain partial AWS/Azure evidence and separate GCP callers by resource project.
- Finite AWS/OCI transport retries.
- Redact multiline YAML credentials before evidence selection.
- Pin GitLab tree pagination to immutable commit.
- Bounded diagnostic redaction and exact Kubernetes claim checks.

### Fixed
- Collection envelope validation and continuation field enforcement.
- Missing required environment value rejection.
- Duplicate YAML key rejection.
- Invalid security gate and malformed configuration rejection before collection.
- Bound HTTP responses and JSON/pagination reads to 16 MiB.
- Destination policy enforcement on injected Request sessions.
- Cross-origin GCP refresh-token redirect prevention.
- AWS account ID preservation including leading zeros.
- Directory exclusion names no longer skip files of the same name.
- Containerfile parsed like a Dockerfile.
- Git author fields use NUL separators with validated timestamps.
- Ruby `=begin` blocks scan in linear time.
- Python 3.12 tokenizer errors mid-file mark the file ambiguous.
- Multi-line structured secrets keep excerpt lines aligned.

### Security
- Credential redaction before findings or record exports are persisted.
- Bound cloud authentication/SDK transport behavior.
- Prevented cross-origin GCP refresh-token redirects.
- API mode skips unsafe tree paths instead of whole repositories.

## [0.1.0] - 2026-09-23

### Added
- Initial release of ShadowScan.
- Six discovery surfaces: code, identity, gateway, low-code, SaaS, cloud.
- 25+ connectors with live and offline modes.
- 178 signatures / 790 signals covering 100+ frameworks and model providers.
- Sanctioned inventory reconciliation with Agent Cards.
- Additive, explainable risk scoring.
- Output formats: table, JSON, SARIF, CSV, Markdown, HTML.
- CLI with `scan`, `run`, `code`, `gateway`, `jwt`, `inventory`, `diff`, and `signatures` commands.
- Apache-2.0 license.

[Unreleased]: https://github.com/aisecnomad/Project-Nexus/compare/v0.1.1...HEAD
[0.1.1]: https://github.com/aisecnomad/Project-Nexus/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/aisecnomad/Project-Nexus/releases/tag/v0.1.0
