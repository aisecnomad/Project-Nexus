<p align="center">
  <img src="https://img.shields.io/badge/ShadowScan-Find_Shadow_AI_Agents-7B2D8E?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0id2hpdGUiPjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0wIDE4Yy00LjQyIDAtOC0zLjU4LTgtOHMzLjU4LTggOC04IDggMy41OCA4IDgtMy41OCA4LTggOHoiLz48Y2lyY2xlIGN4PSIxMiIgY3k9IjEyIiByPSI1Ii8+PC9zdmc+" alt="ShadowScan" />
</p>

<h1 align="center">Project Nexus · ShadowScan</h1>

<p align="center">
  <strong>Discover the AI agents nobody registered. Across every surface they hide.</strong>
</p>

<p align="center">
  <a href="https://github.com/aisecnomad/Project-Nexus/actions"><img src="https://img.shields.io/github/actions/workflow/status/aisecnomad/Project-Nexus/ci.yml?branch=main&style=flat-square&label=CI" alt="CI Status" /></a>
  <a href="https://github.com/aisecnomad/Project-Nexus/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-Apache--2.0-blue?style=flat-square" alt="License" /></a>
  <a href="https://www.python.org/downloads/"><img src="https://img.shields.io/badge/python-3.11%2B-3776AB?style=flat-square&logo=python&logoColor=white" alt="Python 3.11+" /></a>
  <a href="https://github.com/aisecnomad/Project-Nexus/blob/main/CODE_OF_CONDUCT.md"><img src="https://img.shields.io/badge/Contributor%20Covenant-2.1-4baaaa?style=flat-square" alt="Contributor Covenant" /></a>
  <a href="https://github.com/aisecnomad/Project-Nexus/blob/main/SECURITY.md"><img src="https://img.shields.io/badge/security-policy-green?style=flat-square" alt="Security Policy" /></a>
  <a href="https://github.com/aisecnomad/Project-Nexus/releases"><img src="https://img.shields.io/github/v/release/aisecnomad/Project-Nexus?style=flat-square&label=release&color=orange" alt="Latest Release" /></a>
</p>

<p align="center">
  <a href="#why">Why</a> ·
  <a href="#key-capabilities">Capabilities</a> ·
  <a href="#quick-start">Quick Start</a> ·
  <a href="#surfaces--connectors">Connectors</a> ·
  <a href="#configuration">Configuration</a> ·
  <a href="https://github.com/aisecnomad/Project-Nexus/blob/main/CONTRIBUTING.md">Contributing</a> ·
  <a href="https://github.com/aisecnomad/Project-Nexus/blob/main/docs/">Docs</a>
</p>

---

**ShadowScan finds the AI agents nobody registered.** It sweeps the six surfaces where agents hide — code repositories, identity providers, LLM gateway logs, low-code platforms, SaaS apps, and cloud accounts — fingerprints the frameworks and model providers they use, scores their risk, and reconciles every discovery against your sanctioned inventory of [Agent Cards](./Agent%20Card). What is left over is *shadow*.

```
$ shadowscan scan -c shadowscan.yaml --inventory inventory/ --format html -o report.html

╭──────────────────────────────── ShadowScan ────────────────────────────────╮
│ 97 findings  •  94 shadow (inventory: 3 registered agents)                  │
│ critical 14  high 47  medium 35  low 1  •  code 12 identity 21 cloud 27 …   │
╰────────────────────────────────────────────────────────────────────────────╯
 CRITICAL 95  SHADOW  code      mcp-server   MCP configuration: .mcp.json (inline GitHub PAT, Zapier remote MCP, docker/postgres)
 CRITICAL 90  SHADOW  cloud     agent        Bedrock AgentCore runtime: strands_support_agent (plaintext OPENAI_API_KEY, public network)
 CRITICAL 77  SHADOW  identity  token        JWT (delegated-agent) for 0oa2svc-client from okta (RFC 8693 actor chain, okta.users.manage)
 HIGH     73  SHADOW  gateway   caller       Agentic caller 'research-agent-prod': 200 req via LangChain, 100% tool use, 24x7
 MEDIUM   33  ops-provisioning-04  cloud  agent  Bedrock Agent: ops-provisioning-04   ← registered, owner inherited
```

## Why

Agents are no longer only Python scripts. They are Copilot Studio bots built by HR, `n8n` flows with an *AI Agent* node, OAuth grants to meeting note-takers, Bedrock Agents provisioned by Terraform, MCP servers wired into every developer's editor, service principals with `Mail.ReadWrite` acting on behalf of nobody, and JWTs carrying an `act` claim.

Each surface has its own discovery API and its own vocabulary. ShadowScan normalizes all of them into one finding model with evidence, so you can answer three questions for every agent in the estate:

> **Who owns it? What can it do? Did anyone approve it?**

## Key Capabilities

- **6 discovery surfaces** — code, identity, gateway, low-code, SaaS, cloud — with 25+ connectors
- **178 signatures / 790 signals** — YAML-defined, overridable, covering 100+ frameworks and model providers
- **Live + offline** — every connector runs against live APIs or a JSON/CSV/log export for air-gapped and CI use
- **Sanctioned inventory reconciliation** — match findings against your Agent Cards to separate registered from shadow
- **Risk scoring** — additive, explainable scoring based on capabilities, permissions, credential exposure, and ownership
- **Cross-surface correlation** — links Terraform IaC → cloud agent → IAM role → CloudTrail caller into one story
- **Multiple outputs** — terminal table, JSON, SARIF (GitHub code scanning), CSV, Markdown, HTML with drill-down

## Quick Start

### Install

```bash
# Core (code, identity, gateway, low-code, SaaS via REST)
pip install "git+https://github.com/aisecnomad/Project-Nexus.git"

# With cloud provider support (+ boto3, google-auth, azure-identity, oci)
pip install "shadowscan[cloud] @ git+https://github.com/aisecnomad/Project-Nexus.git"
```

**Requirements:** Python 3.11+. Core dependencies are deliberately minimal: `click`, `rich`, `PyYAML`, `requests`, `PyJWT`, `regex`. Cloud SDKs are optional extras.

### Your First Scan

```bash
# 1. Scan a local checkout — no credentials needed
shadowscan code . --inventory inventory/

# 2. Try every connector with bundled fixtures (offline demo)
shadowscan scan -c examples/shadowscan.offline.yaml --format html -o report.html

# 3. Full estate scan with live connectors
shadowscan scan -c shadowscan.yaml --format sarif -o shadowscan.sarif --fail-on high

# 4. Single connector, ad-hoc
shadowscan run identity.entra --set tenant_id=$AZURE_TENANT_ID
shadowscan run cloud.aws --set regions=us-east-1,eu-west-1 --dump-records ./exports

# 5. Analyze gateway logs and JWTs
shadowscan gateway litellm-spend.jsonl bedrock-invocations/ egress-proxy.log
shadowscan jwt "$TOKEN" --jwks-url https://acme.okta.com/oauth2/default/v1/keys

# 6. Register what you found
shadowscan inventory stubs report.json -o inventory/pending/
shadowscan diff last-week.json today.json
```

## Surfaces & Connectors

| Surface      | Connectors | What Is Discovered |
|:-------------|:-----------|:-------------------|
| **Code**     | `code.filesystem`, `code.github`, `code.gitlab` | Agent frameworks & LLM SDKs, MCP client/server configs, coding-agent configs, A2A agent cards, IaC provisioning, container images, CI secret names, hard-coded keys (redacted) |
| **Identity** | `identity.okta`, `identity.entra`, `identity.google-workspace`, `identity.auth0`, `identity.jwt` | OAuth apps & consent grants to AI SaaS, service principals with LLM/data permissions, JWT classification with privilege analysis |
| **Gateway**  | `gateway.logs` | Callers from LiteLLM, Portkey, Kong AI, Cloudflare AI Gateway, Helicone, Langfuse, Bedrock/Azure/Vertex/OpenAI/Anthropic logs: models, frameworks, tool-use ratio, cost |
| **Low-code** | `lowcode.power-platform`, `lowcode.salesforce`, `lowcode.servicenow`, `lowcode.n8n`, `lowcode.make`, `lowcode.zapier`, `lowcode.workato` | Copilot Studio agents, Power Automate AI connectors, Agentforce, Einstein bots, Now Assist agents, workflow automation with AI steps |
| **SaaS**     | `saas.slack`, `saas.microsoft-teams`, `saas.github-apps`, `saas.atlassian`, `saas.notion`, `saas.zoom`, `saas.generic` | Bots and apps with scopes, Teams Copilot agents, GitHub AI apps, Rovo/Marketplace apps, Notion integrations, Zoom meeting bots, CASB exports |
| **Cloud**    | `cloud.aws`, `cloud.gcp`, `cloud.azure`, `cloud.oci` | Bedrock Agents/Flows, Vertex AI agents, Azure OpenAI deployments, AI Foundry, OCI GenAI, IAM policies granting LLM access, CloudTrail callers |

Every connector works **live** (API credentials) or **offline** (JSON/CSV/log export), so the same detection logic runs in CI, on an analyst laptop, or from a SIEM export.

## Configuration

```yaml
# shadowscan.yaml
inventory: [./inventory]              # Agent Capability Cards, agents.yaml, or CSV
signatures: [./custom-signatures]     # Optional: extra or overriding packs
options:
  min_confidence: 0.3
  fail_on: high
  dump_records: ./exports             # Sanitized records for offline re-runs
connectors:
  - name: code.github
    org: acme
    token: ${GITHUB_TOKEN}
  - name: identity.entra
    tenant_id: ${AZURE_TENANT_ID}
    client_id: ${AZURE_CLIENT_ID}
    client_secret: ${AZURE_CLIENT_SECRET}
  - name: gateway.logs
    input: ./exports/litellm-spend.jsonl
  - name: cloud.aws
    regions: [us-east-1, eu-west-1]
    cloudtrail_days: 7
```

Run `shadowscan connectors` to list every connector with its configuration keys, required extras, and offline format. See [docs/connectors.md](./docs/connectors.md) for credentials and least-privilege scopes.

## Frameworks & Products Recognized

178 signatures / 790 signals, YAML-defined and overridable:

**Orchestrators** — LangChain, LangGraph, LlamaIndex, CrewAI, Google ADK, AWS Strands Agents, Semantic Kernel, AutoGen/AG2, OpenAI Agents SDK, Claude Agent SDK, Pydantic AI, Vercel AI SDK, Haystack, DSPy, and 40+ more

**Protocols** — MCP (all config locations, servers, registries, remote hosts), A2A agent cards, ACP, tool/function-calling shapes, ChatGPT plugin manifests

**Coding Agents** — Claude Code, GitHub Copilot, Cursor, Windsurf, Cline, OpenAI Codex, Gemini CLI/Jules, Amazon Q/Kiro, Aider, and more

**Platforms/Gateways** — LiteLLM, Portkey, Kong AI, Dify, Flowise, n8n, Copilot Studio, Agentforce, and more

**Model Providers** — OpenAI, Anthropic, Google, AWS Bedrock, Azure OpenAI, Mistral, Cohere, Groq, and 20+ more (deps, imports, endpoints, env vars, user agents, key formats)

Run `shadowscan signatures list` for the full catalog or `shadowscan signatures test <value>` to see what a package, host, or scope maps to.

## What a Finding Looks Like

```json
{
  "id": "ss-3f9c1e2a7b4d8c10",
  "surface": "cloud", "connector": "cloud.aws", "kind": "agent",
  "title": "Bedrock AgentCore runtime: strands_support_agent",
  "resource": "arn:aws:bedrock-agentcore:us-east-1:123456789012:runtime/rt1",
  "shadow": true,
  "risk": {
    "score": 90, "level": "critical",
    "factors": [
      {"id": "shadow", "description": "not in sanctioned inventory", "weight": 25},
      {"id": "tag:plaintext-credential", "description": "plaintext credential exposed", "weight": 25}
    ]
  },
  "evidence": [
    {"signal": "aws:agentcore-runtime", "weight": 0.97},
    {"signal": "secret:provider.openai", "weight": 0.6}
  ]
}
```

Outputs: `table` (terminal), `json`, `sarif` (GitHub Code Scanning), `csv`, `markdown`, `html` (self-contained, filterable, with evidence drill-down).

## Sanctioned Inventory

Drop your Agent Cards in a directory. The card's `metadata.agent_id` identifies the registration; explicit `discovery.resources` bind it to concrete resources:

```yaml
metadata:
  agent_id: "ops-provisioning-04"
  owner_team: "Platform-Engineering"
discovery:
  resources:
    - "arn:aws:bedrock:*:123456789012:agent/AGENT1"
    - "github:acme/infra-agents"
  names: ["ops provisioning agent"]
```

Simple `agents.yaml` lists and CSV also work. Run `shadowscan inventory stubs` to generate card skeletons from shadow findings. See [docs/inventory.md](./docs/inventory.md).

## Extending

**Signatures** are YAML — add a pack directory with `--signatures` or the `signatures:` config key to add products or override weights. Schema and authoring guide in [docs/signatures.md](./docs/signatures.md).

**Connectors** implement `collect()` (live) and `analyze()` (records → findings) and register through the `shadowscan.connectors` entry-point group. See [docs/architecture.md](./docs/architecture.md).

## Development

```bash
pip install -e ".[dev]"
python -m shadowscan.signatures.validate
ruff check shadowscan tests
pytest -q
shadowscan scan -c examples/shadowscan.offline.yaml
```

See [CONTRIBUTING.md](./CONTRIBUTING.md) for the trust model, PR guidelines, and review gate.

## Safety Notes

- Known credential formats and credential-bearing URLs are **redacted** before findings or exports are persisted.
- Secret stores (Secrets Manager, Key Vault, etc.) are read for **names only**.
- JWTs are never persisted; findings reference a truncated hash.
- Connectors never modify anything — every API call is read-only.

## Project Status

ShadowScan is under active development. The current release focuses on discovery breadth and detection accuracy. See the [CHANGELOG](./CHANGELOG.md) for release history and the [open issues](https://github.com/aisecnomad/Project-Nexus/issues) for planned work.

## Contributing

Contributions are welcome! Whether it's a new connector, signature pack, bug fix, or documentation improvement — we'd love your help.

Please read [CONTRIBUTING.md](./CONTRIBUTING.md) before submitting a PR, and note that all participants are expected to follow our [Code of Conduct](./CODE_OF_CONDUCT.md).

## License

[Apache-2.0](./LICENSE) — see [LICENSE](./LICENSE) for the full text.

## Getting Help

- **Bug reports & feature requests** → [GitHub Issues](https://github.com/aisecnomad/Project-Nexus/issues/new/choose)
- **Security vulnerabilities** → [Security Advisories](https://github.com/aisecnomad/Project-Nexus/security/advisories/new) (see [SECURITY.md](./SECURITY.md))
- **Questions & discussions** → [GitHub Discussions](https://github.com/aisecnomad/Project-Nexus/discussions)
