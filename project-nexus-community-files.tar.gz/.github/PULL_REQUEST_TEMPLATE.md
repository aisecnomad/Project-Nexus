## Summary

<!-- One or two sentences describing what this PR does and why. -->

## Changes

<!-- Describe the changes in detail. For new connectors or signatures, include what is now detected. -->

-

## Motivation

<!-- Link to the issue this addresses, or explain the problem/use case. -->

Closes #

## Type of Change

<!-- Check all that apply. -->

- [ ] 🐛 Bug fix (non-breaking change that fixes an issue)
- [ ] 🚀 New feature (non-breaking change that adds functionality)
- [ ] 🔍 New signatures or detection rules
- [ ] 🔌 New connector
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to change)
- [ ] 📝 Documentation update
- [ ] 🧹 Refactor / code quality (no functional changes)
- [ ] ⚡ Performance improvement
- [ ] 🔒 Security fix

## Testing

<!-- Describe how you tested your changes. -->

- [ ] Added or updated unit tests
- [ ] Tested with offline fixtures
- [ ] Tested with live connector (redact details)
- [ ] Ran the full test suite: `pytest -q --cov=shadowscan`
- [ ] Validated signatures: `python -m shadowscan.signatures.validate`

## Security Checklist

<!-- ShadowScan handles sensitive data. Every PR must satisfy these. -->

- [ ] No raw credentials, JWTs, or tenant identifiers in code, tests, fixtures, or comments
- [ ] Findings fail-closed: limits, malformed input, or denied API → incomplete scan (exit 3), not empty results
- [ ] No new `persist-credentials: true` on checkout actions without justification
- [ ] GitHub Actions pinned by full commit SHA
- [ ] Connector changes remain read-only (no write API calls)

## Documentation

- [ ] Updated `CHANGELOG.md` under **Unreleased**
- [ ] Updated relevant docs in `docs/` if behavior, config, or rollout is affected
- [ ] Updated `README.md` if applicable

## Review Notes

<!-- Anything reviewers should focus on, known limitations, or follow-up work needed. -->

---

> **Reminder:** The author of a change cannot supply the required independent approving review. See [CONTRIBUTING.md](../CONTRIBUTING.md).
