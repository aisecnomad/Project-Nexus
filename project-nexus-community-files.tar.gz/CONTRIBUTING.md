# Contributing to ShadowScan

First off — **thank you** for considering contributing to ShadowScan! Every contribution matters, whether it's a new connector, a signature pack, a bug fix, a documentation improvement, or a typo fix.

This guide will help you get started.

## Table of Contents

- [Code of Conduct](#code-of-conduct)
- [How Can I Contribute?](#how-can-i-contribute)
- [Trust Model](#trust-model)
- [Development Setup](#development-setup)
- [Making Changes](#making-changes)
- [Pull Request Process](#pull-request-process)
- [Coding Standards](#coding-standards)
- [Adding Signatures](#adding-signatures)
- [Adding Connectors](#adding-connectors)
- [Review Gate](#review-gate)
- [Security Reports](#security-reports)

## Code of Conduct

This project is governed by our [Code of Conduct](CODE_OF_CONDUCT.md). By participating, you are expected to uphold it. Please report unacceptable behavior to **[INSERT CONTACT EMAIL]**.

## How Can I Contribute?

There are many ways to contribute, and not all of them involve writing code:

- **Report bugs** — found something broken? [Open a bug report](https://github.com/aisecnomad/Project-Nexus/issues/new?template=bug_report.yml).
- **Report detection issues** — false positive or missed agent? [Let us know](https://github.com/aisecnomad/Project-Nexus/issues/new?template=detection_issue.yml).
- **Suggest features** — have an idea? [Suggest it](https://github.com/aisecnomad/Project-Nexus/issues/new?template=feature_request.yml).
- **Add signatures** — know a framework or product we don't detect? Signature packs are YAML and easy to author.
- **Add connectors** — access to a platform we don't cover? Connectors follow a simple interface.
- **Improve documentation** — clearer docs help everyone.
- **Review pull requests** — independent reviews are required and always welcome.
- **Answer questions** — help others in [Discussions](https://github.com/aisecnomad/Project-Nexus/discussions).

If you're not sure where to start, look for issues labeled [`good first issue`](https://github.com/aisecnomad/Project-Nexus/labels/good%20first%20issue) or [`help wanted`](https://github.com/aisecnomad/Project-Nexus/labels/help%20wanted).

## Trust Model

Understanding the trust model is critical for security-sensitive contributions:

- **Trusted**: the operator workstation or CI runner, the scan configuration, and installed Python packages.
- **Untrusted**: remote API responses, scanned repositories, and offline exports.
- **Privileged**: third-party connectors run with scanner privileges — they are not sandboxed.

## Development Setup

```bash
# Clone the repository
git clone https://github.com/aisecnomad/Project-Nexus.git
cd Project-Nexus

# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Optional: install cloud extras for cloud connector work
pip install -e ".[cloud]"

# Verify everything works
python -m shadowscan.signatures.validate
ruff check shadowscan tests
mypy shadowscan
pytest -q --cov=shadowscan --cov-fail-under=80

# Run an offline scan with bundled fixtures
shadowscan scan -c examples/shadowscan.offline.yaml
```

Cloud extras are optional. Offline fixtures cover cloud connectors — **do not commit live tenant exports.**

## Making Changes

1. **Fork** the repository and create a branch from `main`.
2. **Name your branch** descriptively: `fix/gateway-pagination`, `feat/connector-hubspot`, `docs/architecture-update`.
3. **Write or update tests** for your changes.
4. **Run the full check suite** before submitting:
   ```bash
   ruff check shadowscan tests
   mypy shadowscan
   pytest -q --cov=shadowscan --cov-fail-under=80
   python -m shadowscan.signatures.validate
   ```
5. **Update documentation** if your change affects behavior, configuration, or rollout.
6. **Update `CHANGELOG.md`** under the **Unreleased** section.

## Pull Request Process

1. **Target `main`**. Do not push reviewed security changes directly.
2. Fill out the [PR template](.github/PULL_REQUEST_TEMPLATE.md) completely.
3. Ensure CI passes.
4. Request a review. The author cannot self-approve (see [Review Gate](#review-gate)).
5. Address review feedback.
6. Once approved and CI is green, a maintainer will merge.

### PR Principles

- **Fail-closed**: a limit, malformed export, or denied API must mark the scan incomplete (exit 3) rather than produce empty results.
- **No credential leaks**: do not log raw credentials, JWTs, or unsanitized connector configuration.
- **Pin actions**: pin GitHub Actions by full commit SHA. Do not leave `persist-credentials` enabled on checkouts that don't need to push.
- **Document changes**: update `CHANGELOG.md` and `docs/production.md` when a change affects rollout, finding identity, or credential policy.

## Coding Standards

- **Formatter**: [Ruff](https://docs.astral.sh/ruff/) for both linting and formatting.
- **Type checking**: [mypy](https://mypy.readthedocs.io/) with strict mode.
- **Test coverage**: maintain ≥80% coverage. New features should include tests.
- **Docstrings**: use Google-style docstrings for public functions and classes.
- **Imports**: use absolute imports. Group: stdlib → third-party → local.

## Adding Signatures

Signatures are YAML-defined and live in the `shadowscan/signatures/` directory. To add a new signature:

1. Create or update a YAML file in a signature pack directory.
2. Follow the schema documented in [docs/signatures.md](docs/signatures.md).
3. Validate with `python -m shadowscan.signatures.validate`.
4. Test with `shadowscan signatures test <value>` to verify matching.
5. Include test fixtures that demonstrate the detection.

## Adding Connectors

Connectors implement two methods:

- `collect()` — gather evidence from a live API
- `analyze()` — turn records into findings (works for both live and offline mode)

Register your connector through the `shadowscan.connectors` entry-point group. See [docs/architecture.md](docs/architecture.md) for the full guide and interface contract.

## Review Gate

The author of a change **cannot** supply the required independent approving review. Do not weaken repository rulesets to self-merge. This ensures every change gets an independent security and correctness review.

## Security Reports

**Do not open a public issue for security vulnerabilities.**

Use a [private GitHub security advisory](https://github.com/aisecnomad/Project-Nexus/security/advisories/new). Do not include credentials, private exports, or exploit details in public issues. See [SECURITY.md](SECURITY.md) for the full policy.

---

Thank you for helping make ShadowScan better!
